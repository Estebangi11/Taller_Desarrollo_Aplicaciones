/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package modulos.BienestarEmocional;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author WindowsPC
 */
public class EjerciciosView extends javax.swing.JPanel {
    private DefaultListModel<String> modeloEjercicios;
    /**
     * Creates new form EjerciciosView
     */
    public EjerciciosView() {
        initComponents();
        inicializar();
    }
    
    
    private void inicializar() {
        setLayout(null);
        setBackground(new Color(245, 247, 250));

        // --- Título ---
        JLabel lblTitulo = new JLabel("Ejercicios de Relajación", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(52, 73, 94));
        lblTitulo.setBounds(0, 20, 800, 40);
        add(lblTitulo);

        // --- Lista de ejercicios ---
        modeloEjercicios = new DefaultListModel<>();
        modeloEjercicios.addElement("1. Respiración profunda (5 minutos)");
        modeloEjercicios.addElement("2. Meditación guiada (10 minutos)");
        modeloEjercicios.addElement("3. Relajación muscular progresiva");
        modeloEjercicios.addElement("4. Escucha de sonidos naturales");
        modeloEjercicios.addElement("5. Visualización positiva");
        modeloEjercicios.addElement("6. Ejercicio de gratitud");

        lstEjerciciosRelajacion = new JList<>(modeloEjercicios);
        lstEjerciciosRelajacion.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lstEjerciciosRelajacion.setSelectionBackground(new Color(52, 152, 219));
        lstEjerciciosRelajacion.setSelectionForeground(Color.WHITE);
        lstEjerciciosRelajacion.setBorder(BorderFactory.createTitledBorder("Selecciona un ejercicio"));
        Component lstEjercicios;

        JScrollPane scrollLista = new JScrollPane(lstEjerciciosRelajacion);
        scrollLista.setBounds(150, 100, 500, 250);
        scrollLista.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(scrollLista);

        // --- Botón: Ver Detalles ---
        btnDetalles = new JButton("Ver Detalles");
        btnDetalles.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnDetalles.setBackground(new Color(46, 204, 113));
        btnDetalles.setForeground(Color.WHITE);
        btnDetalles.setFocusPainted(false);
        btnDetalles.setBounds(250, 380, 150, 40);
        add(btnDetalles);

        // --- Botón: Volver ---
        btnVolver = new JButton("Volver");
        btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnVolver.setBackground(new Color(231, 76, 60));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.setBounds(430, 380, 120, 40);
        add(btnVolver);

        // --- Acción: Ver detalles ---
        btnDetalles.addActionListener(e -> {
            String ejercicioSeleccionado = lstEjerciciosRelajacion.getSelectedValue();
            if (ejercicioSeleccionado == null) {
                JOptionPane.showMessageDialog(this,
                        "Por favor, selecciona un ejercicio.",
                        "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Muestra detalles básicos del ejercicio
            JOptionPane.showMessageDialog(this,
                    "Detalles del ejercicio:\n\n" + getDetallesEjercicio(ejercicioSeleccionado),
                    "Ejercicio de Relajación", JOptionPane.INFORMATION_MESSAGE);
        });

        // --- Acción: Volver ---
        btnVolver.addActionListener(e -> {
            JFrame ventanaPadre = (JFrame) SwingUtilities.getWindowAncestor(this);
            ventanaPadre.getContentPane().removeAll();
            ventanaPadre.getContentPane().add(new BienestarView().getContentPane());
            ventanaPadre.revalidate();
            ventanaPadre.repaint();
        });
    }

    // --- Método auxiliar: descripción de cada ejercicio ---
    private String getDetallesEjercicio(String ejercicio) {
        switch (ejercicio) {
            case "1. Respiración profunda (5 minutos)":
                return "Inhala lentamente por la nariz durante 4 segundos, retén 2 segundos y exhala por la boca en 6 segundos.";
            case "2. Meditación guiada (10 minutos)":
                return "Busca un audio de meditación guiada y concéntrate en tu respiración y cuerpo durante 10 minutos.";
            case "3. Relajación muscular progresiva":
                return "Tensa y relaja diferentes grupos musculares, empezando por los pies y subiendo hacia la cabeza.";
            case "4. Escucha de sonidos naturales":
                return "Escucha sonidos del mar, lluvia o bosque durante unos minutos para relajar tu mente.";
            case "5. Visualización positiva":
                return "Imagina un lugar tranquilo y feliz. Visualiza los detalles, colores y sonidos que te transmiten calma.";
            case "6. Ejercicio de gratitud":
                return "Piensa en tres cosas por las que te sientas agradecido hoy. Escríbelas y reflexiona sobre ellas.";
            default:
                return "Ejercicio sin descripción disponible.";
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstEjerciciosRelajacion = new javax.swing.JList<>();
        btnDetalles = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        jLabel1.setText("Ejerccicios para relajarse");

        lstEjerciciosRelajacion.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstEjerciciosRelajacion);

        btnDetalles.setBackground(new java.awt.Color(0, 0, 0));
        btnDetalles.setForeground(new java.awt.Color(255, 255, 255));
        btnDetalles.setText("Ver detalles");
        btnDetalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetallesActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 0, 0));
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(btnVolver)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(140, 140, 140))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(btnVolver)
                .addGap(9, 9, 9)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDetalles)
                .addContainerGap(24, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnDetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetallesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDetallesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDetalles;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstEjerciciosRelajacion;
    // End of variables declaration//GEN-END:variables
}
