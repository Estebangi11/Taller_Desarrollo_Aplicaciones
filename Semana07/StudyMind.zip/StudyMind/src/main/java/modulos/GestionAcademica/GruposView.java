/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package modulos.GestionAcademica;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import vista.DashboardUsuarioView;

/**
 *
 * @author WindowsPC
 */
public class GruposView extends javax.swing.JPanel {
    private DefaultListModel<String> modeloGrupos;
    /**
     * Creates new form GruposView
     */
    public GruposView() {
        initComponents();
        inicializar();
    }
    
    private void inicializar(){
        // --- Panel principal ---
        setLayout(null);
        setBackground(new Color(245, 247, 250));

        // --- Título ---
        JLabel lblTitulo = new JLabel("Grupos de Estudio", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(52, 73, 94));
        lblTitulo.setBounds(0, 20, 800, 40);
        add(lblTitulo);

        // --- Lista de grupos ---
        modeloGrupos = new DefaultListModel<>();
        modeloGrupos.addElement("Grupo 1 - Matemáticas Avanzadas");
        modeloGrupos.addElement("Grupo 2 - Programación en Java");
        modeloGrupos.addElement("Grupo 3 - Psicología Educativa");
        modeloGrupos.addElement("Grupo 4 - Finanzas Personales");
        modeloGrupos.addElement("Grupo 5 - Inglés Intermedio");

        lstGruposEstudio = new JList<>(modeloGrupos);
        lstGruposEstudio.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lstGruposEstudio.setSelectionBackground(new Color(52, 152, 219));
        lstGruposEstudio.setSelectionForeground(Color.WHITE);
        lstGruposEstudio.setBorder(BorderFactory.createTitledBorder("Grupos disponibles"));

        JScrollPane scrollLista = new JScrollPane(lstGruposEstudio);
        scrollLista.setBounds(150, 100, 500, 250);
        add(scrollLista);

        // --- Botón: Unirse ---
        btnUnirse = new JButton("Unirse al grupo");
        btnUnirse.setBounds(150, 370, 160, 40);
        btnUnirse.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnUnirse.setBackground(new Color(46, 204, 113));
        btnUnirse.setForeground(Color.WHITE);
        btnUnirse.setFocusPainted(false);
        btnUnirse.setBorderPainted(false);
        add(btnUnirse);

        // Acción del botón Unirse
        btnUnirse.addActionListener(e -> {
            String seleccionado = lstGruposEstudio.getSelectedValue();
            if (seleccionado != null) {
                JOptionPane.showMessageDialog(this, 
                    "Te has unido a: " + seleccionado, 
                    "Unión exitosa", 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Selecciona un grupo antes de unirte.", 
                    "Advertencia", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });

        // --- Botón: Crear grupo ---
        btnCrear = new JButton("Crear nuevo grupo");
        btnCrear.setBounds(330, 370, 180, 40);
        btnCrear.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCrear.setBackground(new Color(52, 152, 219));
        btnCrear.setForeground(Color.WHITE);
        btnCrear.setFocusPainted(false);
        btnCrear.setBorderPainted(false);
        add(btnCrear);

        // Acción del botón Crear
        btnCrear.addActionListener(e -> {
            String nombreGrupo = JOptionPane.showInputDialog(this, "Ingrese el nombre del nuevo grupo:");
            if (nombreGrupo != null && !nombreGrupo.trim().isEmpty()) {
                modeloGrupos.addElement("Nuevo grupo - " + nombreGrupo);
            } else {
                JOptionPane.showMessageDialog(this, "Debe ingresar un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // --- Botón: Volver ---
        btnVolver = new JButton("Volver");
        btnVolver.setBounds(530, 370, 120, 40);
        btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnVolver.setBackground(new Color(231, 76, 60));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.setBorderPainted(false);
        add(btnVolver);

        // Acción del botón Volver (puedes reemplazar por cambio de panel)
        btnVolver.addActionListener(e -> {  
     JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
    frame.dispose(); // Cierra el JFrame actual
    new TareasView().setVisible(true); 
        });
                }  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelgrupo = new javax.swing.JPanel();
        btnVolver = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstGruposEstudio = new javax.swing.JList<>();
        jScrollBar1 = new javax.swing.JScrollBar();
        btnUnirse = new javax.swing.JButton();
        btnCrear = new javax.swing.JButton();

        btnVolver.setText("volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        jLabel1.setText("Grupos de Estudio");

        jScrollPane1.setViewportView(lstGruposEstudio);

        btnUnirse.setBackground(new java.awt.Color(0, 0, 0));
        btnUnirse.setForeground(new java.awt.Color(255, 255, 255));
        btnUnirse.setText("Unirse al grupo");
        btnUnirse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUnirseActionPerformed(evt);
            }
        });

        btnCrear.setBackground(new java.awt.Color(0, 0, 0));
        btnCrear.setForeground(new java.awt.Color(255, 255, 255));
        btnCrear.setText("Crear un nuevo grupo");
        btnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelgrupoLayout = new javax.swing.GroupLayout(panelgrupo);
        panelgrupo.setLayout(panelgrupoLayout);
        panelgrupoLayout.setHorizontalGroup(
            panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelgrupoLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(panelgrupoLayout.createSequentialGroup()
                .addGroup(panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelgrupoLayout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(jLabel1))
                    .addGroup(panelgrupoLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnVolver)
                            .addGroup(panelgrupoLayout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(btnUnirse)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnCrear)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelgrupoLayout.setVerticalGroup(
            panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelgrupoLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(btnVolver)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUnirse)
                    .addComponent(btnCrear))
                .addGap(55, 55, 55))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelgrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnUnirseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUnirseActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnUnirseActionPerformed

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnCrearActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVolverActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton btnUnirse;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstGruposEstudio;
    private javax.swing.JPanel panelgrupo;
    // End of variables declaration//GEN-END:variables
}
