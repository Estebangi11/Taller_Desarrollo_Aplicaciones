package test;

import DB.ConexionBD;
import java.sql.Connection;

public class TestConexion {
    public static void main(String[] args) {
        System.out.println("=================================");
        System.out.println("  PRUEBA DE CONEXIÓN STUDYMIND");
        System.out.println("=================================\n");
        
        // Probar conexión
        Connection conn = ConexionBD.getConexion();
        
        if (conn != null) {
            System.out.println("\n=================================");
            System.out.println("  ✓ CONEXIÓN EXITOSA");
            System.out.println("=================================");
            ConexionBD.cerrarConexion();
        } else {
            System.out.println("\n=================================");
            System.out.println("  ✗ ERROR EN LA CONEXIÓN");
            System.out.println("=================================");
            System.out.println("\nVerifica:");
            System.out.println("1. MySQL está ejecutándose");
            System.out.println("2. La base de datos 'studymind_db' existe");
            System.out.println("3. Usuario y contraseña son correctos");
        }
    }
}