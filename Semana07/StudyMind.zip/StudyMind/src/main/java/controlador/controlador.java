package controlador;

import dao.*;
import model.*;
import java.util.List;

public class controlador {
    private UsuarioDAO usuarioDAO;
    private TareaDAO tareaDAO;
    
    public controlador() {
        this.usuarioDAO = new UsuarioDAO();
        this.tareaDAO = new TareaDAO();
    }
    
    // ========== MÉTODOS DE USUARIO ==========
    
    public boolean registrarUsuario(Usuario usuario) {
        // Validar que el username no exista
        if (usuarioDAO.existeUsername(usuario.getUsername())) {
            System.out.println("Error: El username ya existe");
            return false;
        }
        return usuarioDAO.registrarUsuario(usuario);
    }
    
    public Usuario validarLogin(String username, String password, int idRol) {
        return usuarioDAO.validarLogin(username, password, idRol);
    }
    
    public List<Usuario> obtenerTodosUsuarios() {
        return usuarioDAO.obtenerTodosUsuarios();
    }
    
    public boolean suspenderUsuario(int idUsuario) {
        return usuarioDAO.actualizarEstadoUsuario(idUsuario, "suspendido");
    }
    
    public boolean activarUsuario(int idUsuario) {
        return usuarioDAO.actualizarEstadoUsuario(idUsuario, "activo");
    }
    
    // ========== MÉTODOS DE TAREA ==========
    
    public boolean registrarTarea(Tarea tarea) {
        return tareaDAO.registrarTarea(tarea);
    }
    
    public List<Tarea> obtenerTareasPorGrupo(int idGrupo) {
        return tareaDAO.obtenerTareasPorGrupo(idGrupo);
    }
    
    public boolean eliminarTarea(int idTarea) {
        return tareaDAO.eliminarTarea(idTarea);
    }
}