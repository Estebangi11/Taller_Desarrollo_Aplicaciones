/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import javax.swing.*;
import java.awt.*;
import modulos.usuario.LoginView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import modulos.AdminDetalles.AdminMonitorView;
/**
 *
 * @author WindowsPC
 */
public class DashboardAdminView extends javax.swing.JFrame {
    private DefaultTableModel modeloAnimo, modeloPublicaciones, modeloUsuarios;
    /**
     * Creates new form DashboardAdminView
     */
    public DashboardAdminView() {
        initComponents();
        inicializar();
    }
    
    private void inicializar() {
        setTitle("Panel de Administración - StudyMind");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(950, 800);
    setLocationRelativeTo(null);
    setResizable(false);

    // Panel principal con scroll vertical
    jPanel1 = new JPanel();
    jPanel1.setBackground(Color.WHITE);
    jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.Y_AXIS));
    JScrollPane scrollPrincipal = new JScrollPane(jPanel1);
    scrollPrincipal.getVerticalScrollBar().setUnitIncrement(16); // scroll más suave
    getContentPane().add(scrollPrincipal);

    // --- Título principal ---
    jLabel1 = new JLabel("Bienvenido a StudyMind", SwingConstants.CENTER);
    jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 24));
    jLabel1.setAlignmentX(CENTER_ALIGNMENT);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 20)));
    jPanel1.add(jLabel1);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 30)));

    // --- Tabla Estados de Ánimo ---
    String[] columnasAnimo = {"ID", "Nombre", "Correo", "Rol", "Estado"};
    modeloAnimo = new DefaultTableModel(columnasAnimo, 0);
    modeloAnimo.addRow(new Object[]{"001", "Juan Pérez", "juan@correo.com", "Usuario", "Activo"});
    modeloAnimo.addRow(new Object[]{"002", "Ana Torres", "ana@correo.com", "Usuario", "Activo"});
    modeloAnimo.addRow(new Object[]{"003", "Luis Gómez", "luis@correo.com", "Moderador", "Suspendido"});
    modeloAnimo.addRow(new Object[]{"004", "Admin", "admin@studymind.com", "Administrador", "Activo"});

    EstadosAnimo = new JTable(modeloAnimo);
    EstadosAnimo.setRowHeight(25);
    EstadosAnimo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    EstadosAnimo.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    EstadosAnimo.getTableHeader().setBackground(new Color(52, 73, 94));
    EstadosAnimo.getTableHeader().setForeground(Color.WHITE);
    EstadosAnimo.setSelectionBackground(new Color(52, 152, 219));
    EstadosAnimo.setSelectionForeground(Color.WHITE);

    jPanel1.add(new JLabel("Estados de Ánimo:"));
    jPanel1.add(Box.createRigidArea(new Dimension(0, 5)));
    JScrollPane scrollAnimo = new JScrollPane(EstadosAnimo);
    scrollAnimo.setPreferredSize(new Dimension(900, 150));
    jPanel1.add(scrollAnimo);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 20)));

    // --- Tabla Publicaciones ---
    modeloPublicaciones = new DefaultTableModel(
            new Object[]{"ID", "Usuario", "Contenido", "Fecha", "Estado"}, 0);
    modeloPublicaciones.addRow(new Object[]{"P001", "Luis Gómez", "Hoy fue un buen día", "2025-10-18", "Visible"});
    modeloPublicaciones.addRow(new Object[]{"P002", "María López", "Necesito apoyo académico", "2025-10-17", "Revisar"});

    Publicaciones = new JTable(modeloPublicaciones);
    Publicaciones.setRowHeight(25);
    Publicaciones.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    Publicaciones.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    Publicaciones.getTableHeader().setBackground(new Color(52, 73, 94));
    Publicaciones.getTableHeader().setForeground(Color.WHITE);
    Publicaciones.setSelectionBackground(new Color(52, 152, 219));
    Publicaciones.setSelectionForeground(Color.WHITE);

    jPanel1.add(new JLabel("Publicaciones:"));
    jPanel1.add(Box.createRigidArea(new Dimension(0, 5)));
    JScrollPane scrollPublicaciones = new JScrollPane(Publicaciones);
    scrollPublicaciones.setPreferredSize(new Dimension(900, 150));
    jPanel1.add(scrollPublicaciones);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 20)));

    // --- Tabla Usuarios ---
    modeloUsuarios = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Correo", "Rol", "Estado"}, 0);
    modeloUsuarios.addRow(new Object[]{"U001", "Juan Pérez", "juan@correo.com", "Usuario", "Activo"});
    modeloUsuarios.addRow(new Object[]{"U002", "Ana Torres", "ana@correo.com", "Usuario", "Activo"});
    modeloUsuarios.addRow(new Object[]{"U003", "Admin", "admin@studymind.com", "Administrador", "Activo"});

    Usuarios = new JTable(modeloUsuarios);
    Usuarios.setRowHeight(25);
    Usuarios.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    Usuarios.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    Usuarios.getTableHeader().setBackground(new Color(52, 73, 94));
    Usuarios.getTableHeader().setForeground(Color.WHITE);
    Usuarios.setSelectionBackground(new Color(52, 152, 219));
    Usuarios.setSelectionForeground(Color.WHITE);

    jPanel1.add(new JLabel("Usuarios:"));
    jPanel1.add(Box.createRigidArea(new Dimension(0, 5)));
    JScrollPane scrollUsuarios = new JScrollPane(Usuarios);
    scrollUsuarios.setPreferredSize(new Dimension(900, 150));
    jPanel1.add(scrollUsuarios);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 30)));

    // --- Botón Cerrar Sesión ---
    btnCerrarSesion = new JButton("Cerrar Sesión");
    btnCerrarSesion.setFont(new Font("Segoe UI", Font.BOLD, 15));
    btnCerrarSesion.setBackground(new Color(231, 76, 60));
    btnCerrarSesion.setForeground(Color.WHITE);
    btnCerrarSesion.setFocusPainted(false);
    btnCerrarSesion.setAlignmentX(CENTER_ALIGNMENT);
    jPanel1.add(btnCerrarSesion);
    jPanel1.add(Box.createRigidArea(new Dimension(0, 20)));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EstadosAnimo = new javax.swing.JTable();
        jScrollBar1 = new javax.swing.JScrollBar();
        btnDetalles = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Publicaciones = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Usuarios = new javax.swing.JTable();
        jScrollBar2 = new javax.swing.JScrollBar();
        jScrollBar3 = new javax.swing.JScrollBar();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        EstadosAnimo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Correo", "Rol", "Estado"
            }
        ));
        jScrollPane1.setViewportView(EstadosAnimo);

        btnDetalles.setText("Ver Detalles");
        btnDetalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetallesActionPerformed(evt);
            }
        });

        jLabel3.setText("Publicaciones:");

        Publicaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Usuario", "Contenido", "Fecha", "Estado"
            }
        ));
        jScrollPane2.setViewportView(Publicaciones);

        jLabel4.setText("Usuarios Registrados:");

        Usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Correo", "Rol", "Estado"
            }
        ));
        jScrollPane3.setViewportView(Usuarios);

        jLabel2.setText("Registros de los estados de animo:");

        jLabel1.setText("PANEL ADMINISTRADOR:");

        btnCerrarSesion.setText("Cerrar Sesion");
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 873, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollBar3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(0, 778, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollBar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(274, 274, 274)
                .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(btnDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Seguro que deseas cerrar sesión?",
                    "Confirmar cierre de sesión", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose(); // cierra la ventana actual
                JOptionPane.showMessageDialog(null,
                        "Sesión cerrada correctamente.",
                        "Logout", JOptionPane.INFORMATION_MESSAGE);
                // Aquí podrías abrir el login nuevamente si lo tienes
            }
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void btnDetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetallesActionPerformed
        // TODO add your handling code here:
         new AdminMonitorView().setVisible(true);
            dispose();
    }//GEN-LAST:event_btnDetallesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardAdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardAdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardAdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardAdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardAdminView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable EstadosAnimo;
    private javax.swing.JTable Publicaciones;
    private javax.swing.JTable Usuarios;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnDetalles;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollBar jScrollBar2;
    private javax.swing.JScrollBar jScrollBar3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
