package model;

import java.util.Date;

public class Tarea {
    private int idTarea;
    private int idGrupo;
    private String titulo;
    private String descripcion;
    private Date fechaLimite;
    private String tipo;
    private Date fechaCreacion;
    
    // Constructor vacío
    public Tarea() {}
    
    // Constructor con parámetros
    public Tarea(int idGrupo, String titulo, String descripcion, Date fechaLimite, String tipo) {
        this.idGrupo = idGrupo;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.tipo = tipo;
    }
    
    // Getters y Setters
    public int getIdTarea() { return idTarea; }
    public void setIdTarea(int idTarea) { this.idTarea = idTarea; }
    
    public int getIdGrupo() { return idGrupo; }
    public void setIdGrupo(int idGrupo) { this.idGrupo = idGrupo; }
    
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    
    public Date getFechaLimite() { return fechaLimite; }
    public void setFechaLimite(Date fechaLimite) { this.fechaLimite = fechaLimite; }
    
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    
    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}